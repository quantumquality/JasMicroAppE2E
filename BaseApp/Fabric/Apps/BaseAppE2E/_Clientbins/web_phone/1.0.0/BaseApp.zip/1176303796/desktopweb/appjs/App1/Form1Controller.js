define("App1/userForm1Controller", {
    //Type your controller code here 
});
define("App1/Form1ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_c0e7021d19bd4ee6b6cf3f663cc1dff1: function AS_Button_c0e7021d19bd4ee6b6cf3f663cc1dff1(eventobject) {
        var self = this;
        this.view.lbl1.text = this.view.TextField0b067357c074749.text;
        this.view.lbl1.text = this.view.tb2.text;
    }
});
define("App1/Form1Controller", ["App1/userForm1Controller", "App1/Form1ControllerActions"], function() {
    var controller = require("App1/userForm1Controller");
    var controllerActions = ["App1/Form1ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
