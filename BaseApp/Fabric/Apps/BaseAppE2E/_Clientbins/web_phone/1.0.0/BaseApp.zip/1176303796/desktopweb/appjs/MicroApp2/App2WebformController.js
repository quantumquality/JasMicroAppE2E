define("MicroApp2/userApp2WebformController", {
    //Type your controller code here 
});
define("MicroApp2/App2WebformControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_i21391a81bad45e7a3dcf756e22a0fee: function AS_Button_i21391a81bad45e7a3dcf756e22a0fee(eventobject) {
        var self = this;
        this.view.lbl1.text = "Changed";
    },
    AS_Button_da81388771694e3bb0d9df146a01c7a5: function AS_Button_da81388771694e3bb0d9df146a01c7a5(eventobject) {
        var self = this;
        this.view.lbl2.text = this.view.TextField0j5ed27cdf2f340.text;
    }
});
define("MicroApp2/App2WebformController", ["MicroApp2/userApp2WebformController", "MicroApp2/App2WebformControllerActions"], function() {
    var controller = require("MicroApp2/userApp2WebformController");
    var controllerActions = ["MicroApp2/App2WebformControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
