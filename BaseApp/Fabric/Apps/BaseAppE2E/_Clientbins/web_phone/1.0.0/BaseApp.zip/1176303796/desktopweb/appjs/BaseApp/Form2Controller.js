define("BaseApp/userForm2Controller", {
    //Type your controller code here 
});
define("BaseApp/Form2ControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Button_i4bbbdb7cc2e4bd8a2e1092d03f0357e: function AS_Button_i4bbbdb7cc2e4bd8a2e1092d03f0357e(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation({
            "appName": "App1",
            "friendlyName": "Form1"
        });
        ntf.navigate();
    },
    AS_Button_d035f77f036248deb6c41c120150f6c4: function AS_Button_d035f77f036248deb6c41c120150f6c4(eventobject) {
        var self = this;
        var ntf = new kony.mvc.Navigation({
            "appName": "MicroApp2",
            "friendlyName": "App2Webform"
        });
        ntf.navigate();
    }
});
define("BaseApp/Form2Controller", ["BaseApp/userForm2Controller", "BaseApp/Form2ControllerActions"], function() {
    var controller = require("BaseApp/userForm2Controller");
    var controllerActions = ["BaseApp/Form2ControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
