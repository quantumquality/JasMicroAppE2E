define("MicroApp2/App2Webform", function() {
    return function(controller) {
        function addWidgetsApp2Webform() {
            this.setDefaultUnit(kony.flex.DP);
            var Button0a013e8a2ea7e4f = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0a013e8a2ea7e4f",
                "isVisible": true,
                "left": "78dp",
                "onClick": controller.AS_Button_i21391a81bad45e7a3dcf756e22a0fee,
                "skin": "defBtnNormal",
                "text": "Change Text",
                "top": "97dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lbl1 = new kony.ui.Label({
                "id": "lbl1",
                "isVisible": true,
                "left": "541dp",
                "skin": "defLabel",
                "text": "Label",
                "top": "111dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var Button0g3e3fbbc5cd641 = new kony.ui.Button({
                "focusSkin": "defBtnFocus",
                "height": "50dp",
                "id": "Button0g3e3fbbc5cd641",
                "isVisible": true,
                "left": "86dp",
                "onClick": controller.AS_Button_da81388771694e3bb0d9df146a01c7a5,
                "skin": "defBtnNormal",
                "text": "Read",
                "top": "254dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var TextField0j5ed27cdf2f340 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "40dp",
                "id": "TextField0j5ed27cdf2f340",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "522dp",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "defTextBoxNormal",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "251dp",
                "width": "300dp",
                "zIndex": 1
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lbl2 = new kony.ui.Label({
                "id": "lbl2",
                "isVisible": true,
                "left": "389dp",
                "skin": "defLabel",
                "text": "Label",
                "top": "400dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            this.compInstData = {}
            this.add(Button0a013e8a2ea7e4f, lbl1, Button0g3e3fbbc5cd641, TextField0j5ed27cdf2f340, lbl2);
        };
        return [{
            "addWidgets": addWidgetsApp2Webform,
            "enabledForIdleTimeout": false,
            "id": "App2Webform",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "MicroApp2"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});